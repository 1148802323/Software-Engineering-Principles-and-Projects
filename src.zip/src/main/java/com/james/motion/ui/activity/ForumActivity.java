package com.james.motion.ui.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.james.motion.R;
import com.james.motion.commmon.bean.ForumPost;
import com.james.motion.commmon.bean.UserAccount;
import com.james.motion.db.DataManager;
import com.james.motion.db.RealmHelper;

import java.sql.Date;
import java.text.DateFormat;
import java.util.List;

public class ForumActivity extends AppCompatActivity {

    // 声明按钮和编辑文本框的引用
    Button buttonPublish;
    EditText editTextContent;
    TextView textViewForumContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forum);



        // 获取按钮、编辑文本框和论坛内容的引用
        buttonPublish = findViewById(R.id.buttonPublish);
        editTextContent = findViewById(R.id.editTextContent);
        textViewForumContent = findViewById(R.id.forumContent);


        updateForumContent();

        // 设置按钮的点击事件监听器
        buttonPublish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 在按钮点击事件中调用发布评论的方法
                publishComment();
            }
        });

        // 找到返回主菜单按钮
        RelativeLayout buttonBackToMainMenu = findViewById(R.id.buttonBackToMainMenu);

        // 设置按钮的点击事件监听器
        buttonBackToMainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 在按钮点击事件中启动返回主菜单的操作
                returnToMainMenu();
            }
        });
    }

    // 发布评论的方法
    private void publishComment() {
        // 获取用户输入的评论内容
        String commentContent = editTextContent.getText().toString().trim();

        // 检查评论内容是否为空
        if (TextUtils.isEmpty(commentContent)) {
            showSuccessDialog("Please enter your comment");
            return;
        }

        // 创建评论对象(评论时间在insert中已添加）
        ForumPost forumPost = new ForumPost();
        forumPost.setContent(commentContent);


        // 将评论插入到数据库中
        RealmHelper realmHelper = new RealmHelper();
        DataManager dataManager = new DataManager(realmHelper);
        dataManager.insertForumPost(forumPost);

        // 更新论坛内容显示
        updateForumContent();

        // 提示用户评论发布成功
        showSuccessDialog("Your comment has been posted successfully");

        // 可选：清空评论输入框
        editTextContent.setText("");
    }

    // 更新论坛内容显示
    private void updateForumContent() {
        // 从数据库中获取所有的评论内容
        RealmHelper realmHelper = new RealmHelper();
        DataManager dataManager = new DataManager(realmHelper);
        List<ForumPost> allPosts = dataManager.queryForumPostList();

        // 构建需要显示的文本
        StringBuilder stringBuilder = new StringBuilder();
        for (ForumPost post : allPosts) {
            // 获取评论的内容、作者和时间戳
            String content = post.getContent();
            long timestamp = post.getTimestamp();

            // 将时间戳转换为人类可读的时间
            Date date = new Date(timestamp);
            String formattedDateTime = DateFormat.getDateTimeInstance().format(date);

            // 将评论内容添加到 StringBuilder 中
            stringBuilder.append("Time: ").append(formattedDateTime).append("\n");
            stringBuilder.append("Content: ").append(content).append("\n\n");
        }

        // 在 TextView 中显示所有评论内容
        textViewForumContent.setText(stringBuilder.toString());
    }



    // 返回主菜单的方法
    private void returnToMainMenu() {
        // 这里添加返回主菜单的逻辑，比如启动主菜单活动或关闭当前活动
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    // 显示消息对话框
    private void showSuccessDialog(String content) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(content)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // 用户点击对话框上的按钮时执行的操作
                        dialog.dismiss(); // 关闭对话框
                    }
                });
        // 创建并显示对话框
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}


