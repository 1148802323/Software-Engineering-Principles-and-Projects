package com.james.motion.ui.permission;

public interface PermissionRetryCallBack {
    void onClick();
}
