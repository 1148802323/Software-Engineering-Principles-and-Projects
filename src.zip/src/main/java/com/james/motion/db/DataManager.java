package com.james.motion.db;

import com.james.motion.commmon.bean.SportMotionRecord;
import com.james.motion.commmon.bean.UserAccount;
import com.james.motion.commmon.bean.ForumPost;

import java.util.List;

public class DataManager implements DBHelper {

    private RealmHelper realmHelper;

    private DataManager() {

    }

    public DataManager(RealmHelper helper) {
        realmHelper = helper;
    }

    @Override
    public void insertSportRecord(SportMotionRecord record) {
        realmHelper.insertSportRecord(record);
    }

    @Override
    public void deleteSportRecord(SportMotionRecord record) {
        realmHelper.deleteSportRecord(record);
    }

    @Override
    public void deleteSportRecord() {
        realmHelper.deleteSportRecord();
    }

    @Override
    public List<SportMotionRecord> queryRecordList(int master) {
        return realmHelper.queryRecordList(master);
    }

    @Override
    public List<SportMotionRecord> queryRecordList(int master, String dateTag) {
        return realmHelper.queryRecordList(master, dateTag);
    }

    @Override
    public List<SportMotionRecord> queryRecordList() {
        return realmHelper.queryRecordList();
    }

    @Override
    public SportMotionRecord queryRecord(int master, long startTime, long endTime) {
        return realmHelper.queryRecord(master, startTime, endTime);
    }

    @Override
    public SportMotionRecord queryRecord(int master, String dateTag) {
        return realmHelper.queryRecord(master, dateTag);
    }

    @Override
    public void closeRealm() {
        realmHelper.closeRealm();
    }

    @Override
    public void insertAccount(UserAccount account) {
        realmHelper.insertAccount(account);
    }

    @Override
    public UserAccount queryAccount(String account) {
        return realmHelper.queryAccount(account);
    }

    @Override
    public boolean checkAccount(String account, String psd) {
        return realmHelper.checkAccount(account, psd);
    }

    @Override
    public boolean checkAccount(String account) {
        return realmHelper.checkAccount(account);
    }

    @Override
    public List<UserAccount> queryAccountList() {
        return realmHelper.queryAccountList();
    }

//评论区数据库处理方法
    @Override
    public void insertForumPost(ForumPost forumPost) {
        realmHelper.insertForumPost(forumPost);
    }

    @Override
    public List<ForumPost> queryForumPostList() {
        return realmHelper.queryForumPostList();
    }

    @Override
    public void deleteForumPost(ForumPost forumPost) {
        realmHelper.deleteForumPost(forumPost);
    }

    public ForumPost getLatestForumPost() {
        // 查询数据库中的所有评论，并按时间戳降序排列，以便获取最新的评论
        List<ForumPost> forumPosts = queryForumPostList();
        if (!forumPosts.isEmpty()) {
            // 返回列表中的第一个元素，即最新的评论
            return forumPosts.get(0);
        } else {
            // 如果数据库中没有评论，则返回 null
            return null;
        }
    }

}
