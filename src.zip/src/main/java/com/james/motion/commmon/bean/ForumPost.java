package com.james.motion.commmon.bean;

import io.realm.RealmObject;

public class ForumPost extends RealmObject {
    private String content;
    private String author;
    private long timestamp;

    public ForumPost() {

    }
    public long getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(long l) {
        this.timestamp = l;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String content) {
        this.author = author;
    }

}
