package com.james.motion.commmon.utils;

public class Conn {

    public static int Delayed = 1500;//延迟

    public static String sdCardPathDown = "";//数据保存路径

    public static final String PagerSize = "12";// 分页加载数据的每页数据量

}
