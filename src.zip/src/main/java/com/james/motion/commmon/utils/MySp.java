package com.james.motion.commmon.utils;

public class MySp {

    public static final String ISLOGIN = "isloign";//是否登录

    public static final String USERID = "userid";//用户ID

    public static final String PHONE = "phone";//手机
    public static final String PASSWORD = "password";//密码

}
